<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Mahasiswa extends CI_Controller {

    public function index(){
        $this->load->model('mahasiswa_model', 'mahasiswa');
        $list_mahasiswa = $this->mahasiswa->getAll();

        $data['list_mahasiswa'] = $list_mahasiswa;
        $this->load->view('layout/header');
        $this->load->view('layout/sidebar');
        $this->load->view('mahasiswa/index',$data);
        $this->load->view('layout/footer');
    }

    public function view(){
        $_nim = $this->input->get('id');
        $this->load->model('mahasiswa_model', 'mahasiswa'); //panggil model
        $data['mhs'] = $this->mahasiswa->findById($_nim);

        $this->load->view('layout/header');
        $this->load->view('layout/sidebar');
        $this->load->view('mahasiswa/view',$data);
        $this->load->view('layout/footer');
    }

        public function create(){
        $data['judul'] = "Form Kelola Mahasiswa";
        $this->load->view('layout/header');
        $this->load->view('layout/sidebar');
        $this->load->view('mahasiswa/create',$data);
        $this->load->view('layout/footer');
    }

    public function save(){
        //panggil model
        $this->load->model('mahasiswa_model','mahasiswa');
        
        $nim = $this->input->post('nim');
        $nama = $this->input->post('nama');
        $gender = $this->input->post('gender');
        $tmp_lahir = $this->input->post('tmp_lahir');
        $tgl_lahir = $this->input->post('tgl_lahir');
        $ipk = $this->input->post('ipk');
        $prodi_kode = $this->input->post('prodi_kode');
        $idedit = $this->input->post('idedit'); //hidden field, ada kalo update

        //buat array 
        $data_mhs[] = $nim; // 1
        $data_mhs[] = $nama; // 2
        $data_mhs[] = $gender; // 3
        $data_mhs[] = $tmp_lahir; // 4
        $data_mhs[] = $tgl_lahir; // 5
        $data_mhs[] = $ipk; // 6
        $data_mhs[] = $prodi_kode; // 7
        //dimasukin ke $data_mhs dibawah 

        if(isset($idedit)){
            //update data lama
            $data_mhs[] = $idedit; // 8
            $this->mahasiswa->update($data_mhs); //data harus berupa array
        }else{
            //save data baru
            // panggil fungsi save yg ada di model
            $this->mahasiswa->save($data_mhs); //data harus berupa array
        }

        //redirect itu mengembalikan halaman
        redirect(base_url().'index.php/mahasiswa/view?id='.$nim,'refresh');
        //base url dari config = localhost/webkampus/   
    }

    //method, form = post
    //url = get
    public function edit(){
        $id = $this->input->get('id');
        //panggil model
        $this->load->model('mahasiswa_model','mahasiswa');
        $mhs_edit = $this->mahasiswa->findById($id);

        $data['judul'] = "Form Edit Mahasiswa";
        $data['mhs_edit'] = $mhs_edit;
        $this->load->view('layout/header');
        $this->load->view('layout/sidebar');
        $this->load->view('mahasiswa/update',$data);
        $this->load->view('layout/footer');
    }

    public function delete(){
        $id = $this->input->get('id');
        //panggil model
        $this->load->model('mahasiswa_model','mahasiswa');
        $this->mahasiswa->delete($id);

        //redirect itu mengembalikan halaman
        redirect(base_url().'index.php/mahasiswa','refresh');
    }
}
?>