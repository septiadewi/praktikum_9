<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Prodi extends CI_Controller {

    public function index(){
        $this->load->model('prodi_model', 'prodi');
        $list_prodi = $this->prodi->getAll();

        $data['list_prodi'] = $list_prodi;
        $this->load->view('layout/header');
        $this->load->view('layout/sidebar');
        $this->load->view('prodi/index',$data);
        $this->load->view('layout/footer');
  
    }

    public function view(){
        $_kode = $this->input->get('id');
        $this->load->model('prodi_model', 'prodi'); //panggil model
        $data['prodi'] = $this->prodi->findById($_kode);

        $this->load->view('layout/header');
        $this->load->view('layout/sidebar');
        $this->load->view('prodi/view',$data);
        $this->load->view('layout/footer');
    }

        public function create(){
        $data['judul'] = "Form Kelola Program Studi";
        $this->load->view('layout/header');
        $this->load->view('layout/sidebar');
        $this->load->view('prodi/create',$data);
        $this->load->view('layout/footer');
    }

    public function save(){
        //panggil model
        $this->load->model('prodi_model','prodi');
        
        $kode = $this->input->post('kode');
        $nama = $this->input->post('nama');
        $kaprodi = $this->input->post('kaprodi');
        $idedit = $this->input->post('idedit'); //hidden field, ada kalo update

        //buat array 
        $data_prodi[] = $kode; // 1
        $data_prodi[] = $nama; // 2
        $data_prodi[] = $kaprodi; // 3
        //dimasukin ke $data_prodi dibawah 

        if(isset($idedit)){
            //update data lama
            $data_prodi[] = $idedit; // 8
            $this->prodi->update($data_prodi); //data harus berupa array
        }else{
            //save data baru
            // panggil fungsi save yg ada di model
            $this->prodi->save($data_prodi); //data harus berupa array
        }

        //redirect itu mengembalikan halaman
        redirect(base_url().'index.php/prodi/view?id='.$kode,'refresh');
        //base url dari config = localhost/webkampus/   
    }

    //method, form = post
    //url = get
    public function edit(){
        $id = $this->input->get('id');
        //panggil model
        $this->load->model('prodi_model','prodi');
        $prodi_edit = $this->prodi->findById($id);

        $data['judul'] = "Form Edit Prodi";
        $data['prodi_edit'] = $prodi_edit;
        $this->load->view('layout/header');
        $this->load->view('layout/sidebar');
        $this->load->view('prodi/update',$data);
        $this->load->view('layout/footer');
    }

    public function delete(){
        $id = $this->input->get('id');
        //panggil model
        $this->load->model('prodi_model','prodi');
        $this->prodi->delete($id);

        //redirect itu mengembalikan halaman
        redirect(base_url().'index.php/prodi','refresh');
    }
}