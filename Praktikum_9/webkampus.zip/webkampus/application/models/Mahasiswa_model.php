<?php
class Mahasiswa_model extends CI_Model {

    private $table = "mahasiswa";
    
    public function getAll(){
        //SELECT * FROM mahasiswa
        $query = $this->db->get($this->table);
        return $query->result();
    }

    public function findById($id){
        //SELECT * FROM mahasiswa WHERE nim=$id;
        $this->db->where("nim", $id);
        $query = $this->db->get($this->table);
        return $query->row();
    }

    public function save($data){
        //INSERT INTO mahasiswa (nim, nama, gender, tmp_lahir, tgl_lahir, prodi_kode, ipk)
        //VALUES ('01234552', 'Zidane Hamizan', 'L', 'Aceh', '28-10-2004', 3.50, "SI")
        $sql = "INSERT INTO mahasiswa (nim, nama, gender, tmp_lahir, tgl_lahir, ipk, prodi_kode)
        VALUES (?,?,?,?,?,?,?)";
        $this->db->query($sql, $data); //data parameter fungsi save yang akan di panggil di controller mahasiswa, sql adalah variabel query diatas
    }

    public function update($data){
        //UPDATE
        $sql = "UPDATE mahasiswa SET nim=?, nama=?, gender=?, tmp_lahir=?, tgl_lahir=?, ipk=?, prodi_kode=? WHERE nim=?";
        $this->db->query($sql, $data); 
    }

    public function delete($id){
        //DELETE FROM mahasiswa WHERE nim=$id;
        $sql = "DELETE FROM mahasiswa WHERE nim=?";
        $this->db->query($sql, array($id)); 
    }
}